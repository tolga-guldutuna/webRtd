﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using NLog;
using System.Net;
using System.Text;

namespace TurkTraktor.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TurkTraktorController : ControllerBase
    {
        private static Logger logger = LogManager.GetCurrentClassLogger();
        private readonly IConfiguration _configuration;
        public TurkTraktorController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpPost]
        public string CallTurktraktorService(string Id, string method, string CUST_TELNR, string CCNTR_TELNR, string CCNTER_UNAME, string CUST_NAME_F, string CUST_NAME_L)
        {
            byte[] numArray;
            string str;
            try
            {
                IConfiguration config = new ConfigurationBuilder()
                    .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                    .Build();

                var asd = _configuration["TurkTraktor:EndPoint"];

                //https://crmqa.turktraktor.com.tr/
                HttpWebRequest webProxy = (HttpWebRequest)WebRequest.Create(new Uri(string.Concat("https://crmqa.turktraktor.com.tr/", method)));
                webProxy.Headers.Add("Accept-Encoding: gzip,deflate");
                webProxy.ContentType = "application/xml";
                webProxy.Method = "POST";
                webProxy.KeepAlive = false;
                string configValue = "GB_INTGRTN";
                string configValue1 = "Mavi2233";
                string base64String = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(string.Concat(configValue, ":", configValue1)));
                webProxy.Headers.Add("Authorization", string.Concat("Basic ", base64String));
                numArray = (method != "call" ? Encoding.ASCII.GetBytes(string.Concat(new string[] { "{\"root\": {\"CHAT_ID\": \"", Id, "\", \"CUST_TELNR\": \"", CUST_TELNR, "\", \"CUST_NAME_F\": \"", CUST_NAME_F, "\", \"CUST_NAME_L\": \"", CUST_NAME_L, "\",\"CCNTER_UNAME\": \"", CCNTER_UNAME, "\"}}" })) : Encoding.ASCII.GetBytes(string.Concat(new string[] { "{\"root\": {\"CALL_ID\": \"", Id, "\", \"CUST_TELNR\": \"", CUST_TELNR, "\", \"CCNTR_TELNR\": \"", CCNTR_TELNR, "\", \"CCNTER_UNAME\": \"", CCNTER_UNAME, "\"}}" })));
                //string str2 = ServiceHelper.getConfigValue("TurkTraktor.ProxyUri", "172.20.164.174:8080");

                string str1 = "172.20.16.58:8080";


                logger.Debug(string.Format("TurkTraktorService proxyUri : {0}", str1));
                webProxy.UseDefaultCredentials = true;
                webProxy.Proxy = new WebProxy(str1, false)
                {
                    Credentials = new NetworkCredential("Turktraktorapp", "CC10Bb55E")
                };
                logger.Debug(string.Format("TurkTraktorService webproxy.Proxy : {0} ", webProxy.Proxy));
                using (Stream requestStream = webProxy.GetRequestStream())
                {
                    requestStream.Write(numArray, 0, (int)numArray.Length);
                }
                HttpWebResponse response = (HttpWebResponse)webProxy.GetResponse();
                if (response.StatusCode != HttpStatusCode.OK)
                {
                    logger.Debug(string.Format("ChatID : {0} servis çağırma işlemi Başarısız, status code : {1} desc: {2}", Id, response.StatusCode, response.StatusDescription));
                }
                else
                {
                    logger.Debug(string.Concat(new object[] { "ChatID : ", Id, " Başarılı : ", response.StatusCode, " desc  : ", response.StatusDescription, "response : ", response.GetResponseStream() }));
                }
                Stream responseStream = response.GetResponseStream();
                byte[] numArray1 = new byte[0x800];
                while (true)
                {
                    int ınt32 = responseStream.Read(numArray1, 0, (int)numArray1.Length);
                    if (ınt32 <= 0)
                    {
                        break;
                    }
                    logger.Debug(string.Concat("ChatID : ", Id, " TraktorServiceResponse: ", Encoding.UTF8.GetString(numArray1)));
                }
                str = Encoding.UTF8.GetString(numArray1);
            }
            catch (Exception exception)
            {
                throw exception;
            }
            return str;
        }

    };

       
}