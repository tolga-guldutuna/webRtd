package com.globalbilgi.turktraktor.service;

import com.globalbilgi.turktraktor.dto.ChatRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.concurrent.atomic.AtomicBoolean;

@RequiredArgsConstructor
@Service
public class ScheduledTaskService {

    private AtomicBoolean isTaskRunning = new AtomicBoolean(false);
    private final ChatService chatService;

    // Her saat 08 dakikada çalışacak görev
    @Scheduled(cron = "0 25 * * * ?")
    public void performTask() {
        if (isTaskRunning.get()) {
             chatService.chatService(ChatRequest.getChatRequest(" "," "," "," "," "));
        }
    }

    public void startTask() {
        isTaskRunning.set(true);
        System.out.println("Task started at " + LocalDateTime.now());
    }

    public void stopTask() {
        isTaskRunning.set(false);
        System.out.println("Task stopped at " + LocalDateTime.now());
    }


}