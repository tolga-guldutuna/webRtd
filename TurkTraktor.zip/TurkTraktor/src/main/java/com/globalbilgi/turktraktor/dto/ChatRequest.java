package com.globalbilgi.turktraktor.dto;


import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ChatRequest {
    private String chat_id;
    private String CUST_TELNR;
    private String CCNTR_TELNR;
    private String CCNTER_UNAME;
    private String CUST_NAME_F;
    private String CUST_NAME_L;

    public static ChatRequest getChatRequest(String chat_id,
                                             String CUST_TELNR,
                                             String CCNTER_UNAME,
                                             String CUST_NAME_F,
                                             String CUST_NAME_L) {
        return ChatRequest.builder()
                .chat_id(chat_id)
                .CUST_TELNR(CUST_TELNR)
                .CCNTER_UNAME(CCNTER_UNAME)
                .CUST_NAME_F(CUST_NAME_F)
                .CUST_NAME_L(CUST_NAME_L)
                .build();
    }

    public static ChatRequest getTurkTraktor(turkTraktorVar turkTraktorVar) {
        com.globalbilgi.turktraktor.dto.turkTraktorVar.InputParameters inputParameters = turkTraktorVar.getInputParameters();
        return ChatRequest.builder()
                .chat_id(inputParameters.getID())
                .CUST_TELNR(inputParameters.getCUST_TELNR())
                .CCNTR_TELNR(inputParameters.getCCNTR_TELNR())
                .CCNTER_UNAME(inputParameters.getCCNTER_UNAME())
                .CUST_NAME_F(inputParameters.getCUST_NAME_F())
                .CUST_NAME_L(inputParameters.getCUST_NAME_L())
                .build();
    }
}