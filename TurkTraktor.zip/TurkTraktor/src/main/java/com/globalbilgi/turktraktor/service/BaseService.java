package com.globalbilgi.turktraktor.service;

import lombok.SneakyThrows;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.TrustStrategy;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.SSLContext;
import java.security.cert.X509Certificate;
import java.util.Base64;
import java.util.Collections;

import static org.springframework.http.HttpHeaders.ACCEPT_ENCODING;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;

@Service
public class BaseService {

    private final Environment env;
    protected final RestTemplate restTemplate;
    protected final HttpHeaders headers;

    public BaseService(Environment env) {
        this.env = env;
        this.headers = new HttpHeaders();
        this.restTemplate = new RestTemplate();
    }

    public RestTemplate createRestTemplate() {
/*
        String proxyHost = env.getProperty("turktraktor.proxy.host");
        val proxyPort = env.getProperty("turktraktor.proxy.port", Integer.class);
        String proxyUsername = env.getProperty("turktraktor.proxy.username");
        String proxyPassword = env.getProperty("turktraktor.proxy.password");

        assert proxyHost != null;
        HttpHost proxy = new HttpHost(proxyHost, (proxyPort != -1) ? proxyPort : 8080);
        DefaultProxyRoutePlanner routePlanner = new DefaultProxyRoutePlanner(proxy);

        CredentialsProvider credsProvider = new BasicCredentialsProvider();
        credsProvider.setCredentials(
                new AuthScope(proxyHost, proxyPort),
                new UsernamePasswordCredentials(proxyUsername, proxyPassword));
*/



        return new RestTemplate();
    }


    public HttpHeaders getHeaders() {
        String userName = env.getProperty("turktraktor.username");
        String password = env.getProperty("turktraktor.password");

        String authStr = userName + ":" + password;
        String base64Creds = Base64.getEncoder().encodeToString(authStr.getBytes());

        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.put(ACCEPT_ENCODING, Collections.singletonList("gzip,deflate"));
        headers.add(AUTHORIZATION, "Basic " + base64Creds);

        return headers;
    }

    public String getEndPoint(){
        return env.getProperty("turktraktor.prod.endpoint");

    }

    @SneakyThrows
    public RestTemplate disableSSLConnect() {
        TrustStrategy acceptingTrustStrategy = (X509Certificate[] chain, String authType) -> true;

        SSLContext sslContext = org.apache.http.ssl.SSLContexts.custom()
                .loadTrustMaterial(null, acceptingTrustStrategy)
                .build();

        SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext);

        CloseableHttpClient httpClient = HttpClients.custom()
                .setSSLSocketFactory(csf)
                .build();

        HttpComponentsClientHttpRequestFactory requestFactory =
                new HttpComponentsClientHttpRequestFactory();

        requestFactory.setHttpClient(httpClient);
        return new RestTemplate(requestFactory);
    }

}
