package com.globalbilgi.turktraktor.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class BaseResponse {
    private String id;
    private String status;
    private int statusCode;
    private String description;


    public BaseResponse(String id, String status, String description) {
        this.id = id;
        this.status = status;
        this.description = description;
    }

    @Override
    public String toString() {
        return String.format("{\n  \"ID\": \"%s\",\n  \"Status\": \"%s\",\n  \"StatusCode\": %d,\n  \"Description\": \"%s\"\n}", id, status, statusCode, description);
    }
}

