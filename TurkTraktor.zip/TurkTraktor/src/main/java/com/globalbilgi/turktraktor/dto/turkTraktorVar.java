package com.globalbilgi.turktraktor.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class turkTraktorVar {
    private String action;
    private String transactionId;
    private String applicationId;
    private String applicationUser;
    private InputParameters inputParameters;

    @Data
    @Builder
    public static class InputParameters {
        private String msisdn;
        private String conversationId;
        private String method;
        private String ID;
        private String CUST_TELNR;
        private String CCNTR_TELNR;
        private String CCNTER_UNAME;
        private String CUST_NAME_F;
        private String CUST_NAME_L;
    }

}
