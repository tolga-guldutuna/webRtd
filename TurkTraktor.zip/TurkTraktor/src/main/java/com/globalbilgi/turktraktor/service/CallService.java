package com.globalbilgi.turktraktor.service;

import com.globalbilgi.turktraktor.dto.BaseErrorHandler;
import com.globalbilgi.turktraktor.dto.BaseResponse;
import com.globalbilgi.turktraktor.dto.CallRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
@RequiredArgsConstructor
public class CallService {

    private final BaseService baseService;

    public BaseResponse callService(CallRequest request) {
        String url = baseService.getEndPoint() + "call";



        try {
            ResponseEntity<String> response = new RestTemplate().postForEntity(url, new HttpEntity<>(getCallRequestBody(request), baseService.getHeaders()), String.class);
            if (response.getStatusCode().is2xxSuccessful()) {
                log.info("Call_ID : {} Succesful, StatusCode : {} desc : {}", request.getCall_id(), response.getStatusCode(), response.getBody());
                return new BaseResponse(request.getCall_id(), "Successful", response.getStatusCode().value(),  response.getStatusCode()+" "+ ((response.getBody()!= null) ? response.getBody() : ""));
            } else {
                log.info("Call_ID: {} Service Call Failed, StatusCode : {} desc: {}", request.getCall_id(), response.getStatusCode(), response.getBody());
                if (response.getStatusCode().value() == 307) {
                    response = baseService.createRestTemplate().postForEntity(url, new HttpEntity<>(getCallRequestBody(request), baseService.getHeaders()), String.class);
                    log.info("Call_ID : {} Succesful, StatusCode : {} desc : {}", request.getCall_id(), response.getStatusCode(), response.getBody());
                }
                return new BaseResponse(request.getCall_id(), "Service Call Failed",response.getStatusCode().value(),  response.getStatusCode()+" "+ ((response.getBody()!= null) ? response.getBody() : ""));
            }
        } catch (Exception e) {
            return BaseErrorHandler.handleError(e, request.getCall_id(), "Call");
        }
    }


    public String getCallRequestBody(CallRequest request) {
        return String.format("{\"root\": {\"CALL_ID\": \"%s\", \"CUST_TELNR\": \"%s\", \"CCNTR_TELNR\": \"%s\", \"CCNTER_UNAME\": \"%s\"}}",
                request.getCall_id(), request.getCUST_TELNR(), request.getCCNTR_TELNR(), request.getCCNTER_UNAME());
    }
}
