package com.globalbilgi.turktraktor.controller;

import com.globalbilgi.turktraktor.dto.BaseResponse;
import com.globalbilgi.turktraktor.dto.CallRequest;
import com.globalbilgi.turktraktor.dto.ChatRequest;
import com.globalbilgi.turktraktor.dto.turkTraktorVar;
import com.globalbilgi.turktraktor.service.CallService;
import com.globalbilgi.turktraktor.service.ChatService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("")
@Slf4j
@RequiredArgsConstructor
@CrossOrigin(origins = "*", maxAge = 3600)
public class GeneralController {

    private final ChatService chatService;
    private final CallService callService;

    @PostMapping("/call")
    public ResponseEntity<BaseResponse> callService(@RequestBody turkTraktorVar turkTraktorVar) {
        CallRequest callRequest = CallRequest.getTurkTraktor(turkTraktorVar);
        log.info("Call_ID : {} call started, desc : {}", callRequest.getCall_id(), callRequest);
        BaseResponse response = callService.callService(callRequest);
        return ResponseEntity.status(response.getStatusCode())
                .body(response);
    }

    @PostMapping("/chat")
    public ResponseEntity<BaseResponse> chatService(@RequestBody turkTraktorVar turkTraktorVar) {
        ChatRequest chatRequest = ChatRequest.getTurkTraktor(turkTraktorVar);
        log.info("Chat_ID : {} chat started, desc : {}", chatRequest.getChat_id(), chatRequest);
        BaseResponse response = chatService.chatService(chatRequest);
        return ResponseEntity.status(response.getStatusCode())
                .body(response);
    }
}
