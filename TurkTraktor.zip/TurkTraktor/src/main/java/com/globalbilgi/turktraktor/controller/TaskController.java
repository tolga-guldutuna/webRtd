package com.globalbilgi.turktraktor.controller;

import com.globalbilgi.turktraktor.service.ScheduledTaskService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/task")
@Slf4j
@RequiredArgsConstructor
public class TaskController {

    private final ScheduledTaskService scheduledTaskService;

    @GetMapping("/start")
    public String startTask() {
        scheduledTaskService.startTask();
        return "Task started!";
    }

    @GetMapping("/stop")
    public String stopTask() {
        scheduledTaskService.stopTask();
        return "Task stopped!";
    }

}
