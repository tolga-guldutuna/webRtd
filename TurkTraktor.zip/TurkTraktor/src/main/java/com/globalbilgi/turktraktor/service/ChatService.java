package com.globalbilgi.turktraktor.service;

import com.globalbilgi.turktraktor.dto.BaseErrorHandler;
import com.globalbilgi.turktraktor.dto.BaseResponse;
import com.globalbilgi.turktraktor.dto.ChatRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
@RequiredArgsConstructor
public class ChatService {

    private final BaseService baseService;

    public BaseResponse chatService(ChatRequest request) {
        String url = baseService.getEndPoint() + "chat";

        try {
            ResponseEntity<String> response = new RestTemplate().exchange(url, HttpMethod.POST,new HttpEntity<>(getChatRequestBody(request), baseService.getHeaders()), String.class);
            if (response.getStatusCode().is2xxSuccessful()) {
                log.info("Chat_ID : {} Successful, StatusCode : {} desc : {}", request.getChat_id(), response.getStatusCode(), response.getBody());
                return new BaseResponse(request.getChat_id(), "Successful",response.getStatusCode().value(), response.getStatusCode()+" "+ ((response.getBody()!= null) ? response.getBody() : ""));
            } else {
                log.info("Chat_ID: {} Service Call Failed, StatusCode : {} desc: {}", request.getChat_id(), response.getStatusCode(), response.getBody());
                if (response.getStatusCode().value() == 307) {
                    response = new RestTemplate().exchange(url, HttpMethod.POST,new HttpEntity<>(getChatRequestBody(request), baseService.getHeaders()), String.class);
                    log.info("Chat_ID : {} Successful, StatusCode : {} desc : {}", request.getChat_id(), response.getStatusCode(), response.getBody());
                    return new BaseResponse(request.getChat_id(), "Successful",response.getStatusCode().value(), response.getStatusCode()+" "+ ((response.getBody()!= null) ? response.getBody() : ""));
                }
                return new BaseResponse(request.getChat_id(), "Service Call Failed",response.getStatusCode().value(), response.getStatusCode()+" "+ ((response.getBody()!= null) ? response.getBody() : ""));
            }
        } catch (Exception e) {
            return BaseErrorHandler.handleError(e, request.getChat_id(), "Chat");
        }

    }

    public String getChatRequestBody(ChatRequest request) {
        return String.format("{\"root\": {\"CHAT_ID\": \"%s\", \"CUST_TELNR\": \"%s\", \"CUST_NAME_F\": \"%s\", \"CUST_NAME_L\": \"%s\",\"CCNTER_UNAME\": \"%s\"}}",
                request.getChat_id(), request.getCUST_TELNR(), request.getCUST_NAME_F(), request.getCUST_NAME_L(), request.getCCNTER_UNAME());
    }



}
