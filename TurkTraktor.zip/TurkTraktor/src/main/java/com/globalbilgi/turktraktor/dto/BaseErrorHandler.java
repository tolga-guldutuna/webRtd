package com.globalbilgi.turktraktor.dto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;

@Slf4j
public class BaseErrorHandler {
    public static BaseResponse handleError(Exception e, String id, String type) {
        if (e instanceof HttpClientErrorException) {
            HttpClientErrorException clientError = (HttpClientErrorException) e;
            log.warn("{}_ID: {} Client Error: {} desc: {}", type, id, clientError.getStatusCode(), clientError.getResponseBodyAsString());
            return new BaseResponse(id, "Client Error",clientError.getStatusCode().value(), clientError.getResponseBodyAsString());
        } else if (e instanceof HttpServerErrorException) {
            HttpServerErrorException serverError = (HttpServerErrorException) e;
            log.error("{}_ID: {} Server Error: {} desc: {}", type, id, serverError.getStatusCode(), serverError.getResponseBodyAsString());
            return new BaseResponse(id, "Server Error", serverError.getStatusCode().value(), serverError.getResponseBodyAsString());
        } else if (e instanceof ResourceAccessException) {
            ResourceAccessException accessError = (ResourceAccessException) e;
            log.error("{}_ID: {} Connection Error: {}", type, id, accessError.getMessage());
            return new BaseResponse(id, "Connection Error", accessError.getMessage());
        } else {
            log.error("{}_ID: {} Unknown Error: {}", type, id, e.getMessage());
            return new BaseResponse(id, "Unknown Error", e.getMessage());
        }
    }
}
