setTimeout(function () {
    var turkTraktorVar = {
        "action": "INFO_BOT_TURKTRAKTOR",
        "transactionId": "{callId}",
        "applicationId": "5",
        "applicationUser": "sirius",
        "inputParameters": {
            "msisdn": "4123",
            "conversationId": "123",
            "method": "call",
            "ID": "{callId}",
            "CUST_TELNR": "{ani}",
            "CCNTR_TELNR": "-",
            "CCNTER_UNAME": "{username}",
            "CUST_NAME_F": "-",
            "CUST_NAME_L": "-"
        }
    };
    $.ajax({
        type: 'POST',
        url: 'http://10.12.135.22:8090/TurkTraktor/call',
        contentType: "application/json",
        data: JSON.stringify(turkTraktorVar),
        dataType: 'json',
        timeout: 5000,
        success: function (data, textStatus, jqXHR) {
            console.log(JSON.stringify(turkTraktorVar));
        },
        error: function (responseData, textStatus, errorThrown) {
            console.log(JSON.stringify(turkTraktorVar));
            console.log('response geliyor');
            console.log(responseData);
            console.log(errorThrown);
        }
    });
}, 1000);