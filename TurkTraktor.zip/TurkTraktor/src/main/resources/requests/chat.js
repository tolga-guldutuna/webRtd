setTimeout(function () {
    var turkTraktorVar = {
        "action": "INFO_BOT_TURKTRAKTOR",
        "transactionId": "{chatUuid}",
        "applicationId": "5",
        "applicationUser": "sirius",
        "inputParameters": {
            "msisdn": "4123",
            "conversationId": "123",
            "method": "chat",
            "ID": "{chatUuid}",
            "CUST_TELNR": "{chatInputValue['msisdn']}",
            "CUST_NAME_F": "{chatInputValue['ad']}",
            "CUST_NAME_L": "{chatInputValue['soyad']}",
            "CCNTER_UNAME": "{chatQueueName}",
            "CCNTR_TELNR": "-"
        }
    };
    $.ajax({
        type: 'POST',
        url: 'http://10.12.135.22:8090/TurkTraktor/chat',
        contentType: "application/json",
        data: JSON.stringify(turkTraktorVar),
        dataType: 'json',
        processData: false,
        timeout: 10000,
        success: function (data, textStatus, jqXHR) {
            console.log(JSON.stringify(turkTraktorVar));
        },
        error: function (responseData, textStatus, errorThrown) {
            console.log(JSON.stringify(turkTraktorVar));
            console.log('response geliyor');
            console.log(responseData);
            console.log(errorThrown);
        }
    });
}, 10000);