let localStream;
let isMuted = false;
let isCameraOff = false;

// Link üretme ve kopyalama fonksiyonu
const generateLink = () => {
    const generatedLink = `https://example.com/meeting/${Math.random().toString(36).substring(2, 15)}`;
    document.getElementById('generatedLink').value = generatedLink;
};

// Link kopyalama fonksiyonu
document.getElementById('copyLinkButton').addEventListener('click', () => {
    const linkInput = document.getElementById('generatedLink');
    linkInput.select();
    linkInput.setSelectionRange(0, 99999); // Mobil cihazlar için
    document.execCommand('copy');
    npm
});

// Kamera ve mikrofonu başlatma
async function startMedia() {
    try {
        localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        document.getElementById('localVideo').srcObject = localStream;
    } catch (err) {
        console.error('Media error:', err);
    }
}

// Kamerayı aç/kapat
document.getElementById('cameraButton').addEventListener('click', () => {
    isCameraOff = !isCameraOff;
    if (localStream && localStream.getVideoTracks().length > 0) {
        localStream.getVideoTracks()[0].enabled = !isCameraOff;
        document.getElementById('cameraButton').textContent = isCameraOff ? 'Kamerayı Aç' : 'Kamerayı Kapat';
    }
});

// Mikrofonu aç/kapat
document.getElementById('muteButton').addEventListener('click', () => {
    isMuted = !isMuted;
    if (localStream && localStream.getAudioTracks().length > 0) {
        localStream.getAudioTracks()[0].enabled = !isMuted;
        document.getElementById('muteButton').textContent = isMuted ? 'Mikrofonu Aç' : 'Mikrofonu Kapat';
    }
});

// Bağlantıyı başlat
document.getElementById('startButton').addEventListener('click', startMedia);

// Linki üret
generateLink();
