let localStream;
let isMuted = true; // Başlangıçta mikrofon kapalı
let isCameraOff = true; // Başlangıçta kamera kapalı

const cameraStatusElement = document.getElementById('cameraStatus');
const micStatusElement = document.getElementById('micStatus');
const startButton = document.getElementById('startButton');
const hangupButton = document.getElementById('hangupButton');
const muteButton = document.getElementById('muteButton');
const cameraButton = document.getElementById('cameraButton');

// Kamera ve mikrofonu başlatma fonksiyonu
async function startMedia() {
    try {
        localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        document.getElementById('localVideo').srcObject = localStream;

        // Kamera ve mikrofon başlangıçta kapalı olacak
        localStream.getVideoTracks()[0].enabled = false;
        localStream.getAudioTracks()[0].enabled = false;

        // Butonları etkinleştir
        hangupButton.disabled = false;
        muteButton.disabled = false;
        cameraButton.disabled = false;

        // Durumları güncelle
        cameraStatusElement.textContent = 'Kapalı';
        micStatusElement.textContent = 'Kapalı';
    } catch (err) {
        console.error('Media error:', err);
    }
}

// Mikrofon aç/kapat
muteButton.addEventListener('click', () => {
    isMuted = !isMuted;
    localStream.getAudioTracks()[0].enabled = !isMuted;
    muteButton.textContent = isMuted ? 'Mikrofonu Aç' : 'Mikrofonu Kapat';
    
    // Mikrofon durumu güncelle
    micStatusElement.textContent = isMuted ? 'Kapalı' : 'Açık';
    micStatusElement.dataset.status = isMuted ? 'off' : 'on';
});

// Kamera aç/kapat
cameraButton.addEventListener('click', () => {
    isCameraOff = !isCameraOff;
    localStream.getVideoTracks()[0].enabled = !isCameraOff;
    cameraButton.textContent = isCameraOff ? 'Kamerayı Aç' : 'Kamerayı Kapat';

    // Kamera durumu güncelle
    cameraStatusElement.textContent = isCameraOff ? 'Kapalı' : 'Açık';
    cameraStatusElement.dataset.status = isCameraOff ? 'off' : 'on';
});

// Bağlantıyı başlat butonuna tıklandığında medya başlasın
startButton.addEventListener('click', startMedia);
