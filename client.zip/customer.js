let localStream;
let isMuted = false;
let isCameraOff = false;

const cameraStatusElement = document.getElementById('cameraStatus');
const micStatusElement = document.getElementById('micStatus');
const cameraText = document.getElementById('cameraText');
const micText = document.getElementById('micText');
const startButton = document.getElementById('startButton');
const hangupButton = document.getElementById('hangupButton');
const muteButton = document.getElementById('muteButton');
const cameraButton = document.getElementById('cameraButton');
const localVideo = document.getElementById('localVideo');
const cameraPlaceholder = document.getElementById('cameraOffPlaceholder');

async function startMedia() {
    try {
        localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        localVideo.srcObject = localStream;

        localStream.getVideoTracks()[0].enabled = true;
        localStream.getAudioTracks()[0].enabled = true;

        hangupButton.disabled = false;
        muteButton.disabled = false;
        cameraButton.disabled = false;

        updateStatus('on', 'on');
        showVideo();
    } catch (err) {
        console.error('Media error:', err);
    }
}

startButton.addEventListener('click', startMedia);

hangupButton.addEventListener('click', () => {
    if (localStream) {
        localStream.getTracks().forEach(track => track.stop());
    }
    window.open('', '_self').close();
});

muteButton.addEventListener('click', () => {
    isMuted = !isMuted;
    localStream.getAudioTracks()[0].enabled = !isMuted;
    muteButton.textContent = isMuted ? 'Mikrofonu Aç' : 'Mikrofonu Kapat';
    updateMicStatus(isMuted ? 'off' : 'on');
});

cameraButton.addEventListener('click', () => {
    isCameraOff = !isCameraOff;
    localStream.getVideoTracks()[0].enabled = !isCameraOff;
    cameraButton.textContent = isCameraOff ? 'Kamerayı Aç' : 'Kamerayı Kapat';
    updateCameraStatus(isCameraOff ? 'off' : 'on');
    if (isCameraOff) {
        hideVideo();
    } else {
        showVideo();
    }
});

function hideVideo() {
    localVideo.style.display = 'none';
    cameraPlaceholder.style.display = 'block';
}

function showVideo() {
    localVideo.style.display = 'block';
    cameraPlaceholder.style.display = 'none';
}

function updateStatus(cameraStatus, micStatus) {
    updateCameraStatus(cameraStatus);
    updateMicStatus(micStatus);
}

function updateCameraStatus(status) {
    cameraStatusElement.dataset.status = status;
    cameraText.textContent = status === 'on' ? 'Açık' : 'Kapalı';
}

function updateMicStatus(status) {
    micStatusElement.dataset.status = status;
    micText.textContent = status === 'on' ? 'Açık' : 'Kapalı';
}
