const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const open = require('open');  // Tarayıcıda sayfa açmak için kullanılır

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

app.use(express.static(__dirname));  // Public dosyalar için dizini ayarla

io.on('connection', (socket) => {
    console.log('A user connected');

    socket.on('join-room', (roomId) => {
        socket.join(roomId);
        socket.emit('room-joined', roomId);
        console.log(`User joined room: ${roomId}`);
    });

    socket.on('offer', ({ offer, roomId }) => {
        socket.to(roomId).emit('offer', { offer, roomId });
    });

    socket.on('answer', ({ answer, roomId }) => {
        socket.to(roomId).emit('answer', { answer, roomId });
    });

    socket.on('ice-candidate', ({ candidate, roomId }) => {
        socket.to(roomId).emit('ice-candidate', { candidate, roomId });
    });

    socket.on('leave-room', (roomId) => {
        socket.leave(roomId);
        console.log(`User left room: ${roomId}`);
    });

    socket.on('disconnect', () => {
        console.log('A user disconnected');
    });
});

server.listen(8095, async () => {
    console.log('Server is listening on port 8095');

    // 'open' paketini dinamik import ile yükle
    const open = (await import('open')).default;
    open('http://localhost:8095/representative.html');  // Temsilci sayfasını otomatik açar
});
