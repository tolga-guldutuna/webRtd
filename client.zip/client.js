const localVideo = document.getElementById('localVideo');
const remoteVideo = document.getElementById('remoteVideo');
const startButton = document.getElementById('startButton');
const muteAudioButton = document.getElementById('muteAudioButton');
const muteVideoButton = document.getElementById('muteVideoButton');
const hangupButton = document.getElementById('hangupButton');
const generateLinkButton = document.getElementById('generateLinkButton');
const roomLink = document.getElementById('roomLink');
const copyButton = document.getElementById('copyButton');
const cameraStatus = document.getElementById('cameraStatus');
const micStatus = document.getElementById('micStatus');
const repStatus = document.getElementById('repStatus');
const callTimer = document.getElementById('callTimer'); // Call duration timer

let localStream;
let remoteStream;
let peerConnection;
let roomId = '';
let callStartTime; // To store the time when the call starts
let timerInterval; // To store the interval for updating the call duration

const socket = io();

const servers = {
    iceServers: [
        {
            urls: 'stun:stun.l.google.com:19302'
        }
    ]
};

// Function to start the call timer
function startCallTimer() {
    callStartTime = new Date(); // Record the start time
    timerInterval = setInterval(() => {
        const currentTime = new Date();
        const elapsedTime = Math.floor((currentTime - callStartTime) / 1000); // Elapsed time in seconds

        const minutes = Math.floor(elapsedTime / 60);
        const seconds = elapsedTime % 60;
        callTimer.textContent = `Süre: ${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }, 1000);
}

// Function to stop the call timer
function stopCallTimer() {
    clearInterval(timerInterval); // Stop the interval
    callTimer.textContent = 'Süre: 00:00'; // Reset the timer display
}

// Bağlantıyı başlatma butonuna tıklandığında
startButton.addEventListener('click', async () => {
    // Yerel video ve ses akışını başlat
    localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
    localVideo.srcObject = localStream;

    // Temsilci durumunu "online" olarak güncelle
    repStatus.textContent = 'Temsilci: Online';
    repStatus.setAttribute('data-status', 'online');

    // Call timer başlat
    startCallTimer();

    // PeerConnection başlat
    peerConnection = new RTCPeerConnection(servers);

    // Yerel videoyu peerConnection'a ekle
    localStream.getTracks().forEach(track => {
        peerConnection.addTrack(track, localStream);
    });

    // Uzak videoyu alma
    peerConnection.ontrack = (event) => {
        remoteStream = event.streams[0];
        remoteVideo.srcObject = remoteStream;
    };

    // ICE candidate işlemi
    peerConnection.onicecandidate = (event) => {
        if (event.candidate) {
            socket.emit('ice-candidate', { candidate: event.candidate, roomId });
        }
    };

    // ICE bağlantı teklifini oluştur ve karşı tarafa gönder
    const offer = await peerConnection.createOffer();
    await peerConnection.setLocalDescription(offer);
    socket.emit('offer', { offer, roomId });
});

// Teklif alma ve karşılık verme
socket.on('offer', async ({ offer, roomId: incomingRoomId }) => {
    if (!peerConnection) {
        peerConnection = new RTCPeerConnection(servers);

        peerConnection.ontrack = (event) => {
            remoteStream = event.streams[0];
            remoteVideo.srcObject = remoteStream;
        };

        peerConnection.onicecandidate = (event) => {
            if (event.candidate) {
                socket.emit('ice-candidate', { candidate: event.candidate, roomId: incomingRoomId });
            }
        };
    }

    await peerConnection.setRemoteDescription(offer);
    const answer = await peerConnection.createAnswer();
    await peerConnection.setLocalDescription(answer);
    socket.emit('answer', { answer, roomId: incomingRoomId });
});

socket.on('answer', async ({ answer }) => {
    await peerConnection.setRemoteDescription(answer);
});

socket.on('ice-candidate', async ({ candidate }) => {
    try {
        await peerConnection.addIceCandidate(candidate);
    } catch (e) {
        console.error('Error adding received ice candidate', e);
    }
});

// Bağlantıyı kesme
hangupButton.addEventListener('click', () => {
    if (peerConnection) {
        peerConnection.close();
        peerConnection = null;
        remoteVideo.srcObject = null;
        localVideo.srcObject = null;
        socket.emit('leave-room', roomId);

        // Temsilci durumunu "offline" olarak güncelle
        repStatus.textContent = 'Temsilci: Offline';
        repStatus.setAttribute('data-status', 'offline');

        // Call timer durdur
        stopCallTimer();
    }
});

// Ses kapatma/açma
muteAudioButton.addEventListener('click', () => {
    const isAudioEnabled = localStream.getAudioTracks()[0].enabled = !localStream.getAudioTracks()[0].enabled;
    muteAudioButton.textContent = isAudioEnabled ? 'Mute Audio' : 'Unmute Audio';

    // Update microphone status
    micStatus.textContent = isAudioEnabled ? 'Mikrofon: Açık' : 'Mikrofon: Kapalı';
    micStatus.setAttribute('data-status', isAudioEnabled ? 'on' : 'off');
});

// Video kapatma/açma
muteVideoButton.addEventListener('click', () => {
    const isVideoEnabled = localStream.getVideoTracks()[0].enabled = !localStream.getVideoTracks()[0].enabled;
    muteVideoButton.textContent = isVideoEnabled ? 'Mute Video' : 'Unmute Video';

    // Update camera status
    cameraStatus.textContent = isVideoEnabled ? 'Kamera: Açık' : 'Kamera: Kapalı';
    cameraStatus.setAttribute('data-status', isVideoEnabled ? 'on' : 'off');
});

// Oda linkini oluşturma fonksiyonu
if (generateLinkButton) {
    generateLinkButton.addEventListener('click', () => {
        roomId = generateRoomId();
        roomLink.value = `${window.location.origin}/customer.html?roomId=${roomId}`;
        socket.emit('join-room', roomId);
    });
}

// Linki kopyalama
if (copyButton) {
    copyButton.addEventListener('click', () => {
        roomLink.select();
        roomLink.setSelectionRange(0, 99999); // Mobil cihazlar için
        document.execCommand('copy');
        alert("Link kopyalandı!");
    });
}

function generateRoomId() {
    return Math.random().toString(36).substr(2, 9);
}

// Odaya giriş
window.onload = () => {
    const params = new URLSearchParams(window.location.search);
    const roomIdParam = params.get('roomId');
    if (roomIdParam) {
        roomId = roomIdParam;
        socket.emit('join-room', roomId);
    }
};
